Controls:
Move with WASD or analog sticks

Default atks:
Left Mouse Button OR R2: Skill 1
Right Mouse Button OR L2: Skill 17
Shift OR R3: Skill 3
Q OR L1: Skill 7
E OR R1: Skill 9

Attacks will be aim towards the mouse.

Haven't tested gamepad in awhile, so not sure if it still works.

If you find any bugs or crashes let me know. In the QABS help there isn't much yet.
It has a list of all the enemy / state notetags you can use. And a list of all the actions for a 
skill sequence. But it's nearly identical to QuasiABS, and you can find those docs here:
http://quxios.github.io/Quasi-MV-ABS-Demo/

